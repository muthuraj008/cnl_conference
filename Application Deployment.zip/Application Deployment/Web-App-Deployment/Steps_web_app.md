Azure web app deployment.

Steps:
1. Clone application from Github
2. Right on project and select publish(Image : right_project)
3. Select Add a publish profile(Image: add_publish_profile)
4. Choose Azure(Publish your application to the Microsoft cloud)(image:select_publish_azure)
5. Click next and select "Azure App service(windows)". (Image: App_service_windows).
6. Create new resource group where the web app will create, click on plus button.(Image: add_resource_group).
7. Goto resource group and click new and provide resource group name.(new_resource_group).
8. Select publish in the top of the file.(image: publish).
9. After the deployment site goto azure app services, select newly created app services and click on url(image: click_url).
10. Application will run without any error.  